// Call the dataTables jQuery plugin
$(document).ready(function() {

    cargarProductos();

  $('#productos').DataTable();
});

async function cargarProductos(){


  const request = await fetch('productos', {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },

  });
  const productos = await request.json();

  console.log(productos);


  let listadoHtml = ``;

  for (let producto of productos) {


    let productoHtml = `<tr><td>`+ producto.codigo +`
    </td><td>`+ producto.nombre +`</td><td>
    `+ producto.descripcion +`</td><td>
    `+ producto.vencimiento +`</td><td>
    `+ producto.precio +`</td></tr>`;

    listadoHtml += productoHtml;
  }


document.querySelector(`#productos tbody`).outerHTML = listadoHtml;

}