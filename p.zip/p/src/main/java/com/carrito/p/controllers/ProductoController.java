package com.carrito.p.controllers;


import com.carrito.p.models.Producto;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ProductoController {

   @RequestMapping(value = "producto/{codigo}")
    public Producto getProducto(@PathVariable String codigo) {
       Producto producto = new Producto();
       producto.setCodigo("1");
       producto.setNombre("manzana");
       producto.setDescripcion("roja");
       producto.setVencimiento("27/10/24");
       producto.setPrecio("Q.3.00");
        return producto;
    }


    @RequestMapping(value = "productos")
    public List<Producto> getProductos() {
        List<Producto> productos = new ArrayList<>();
        Producto producto = new Producto();
        producto.setCodigo("1");
        producto.setNombre("uvas");
        producto.setDescripcion("verdes");
        producto.setVencimiento("27/10/24");
        producto.setPrecio("Q.10.00");

        Producto producto2 = new Producto();
        producto2.setCodigo("2");
        producto2.setNombre("manzana");
        producto2.setDescripcion("roja");
        producto2.setVencimiento("27/10/24");
        producto2.setPrecio("Q.3.00");

        Producto producto3 = new Producto();
        producto3.setCodigo("3");
        producto3.setNombre("coca-cola");
        producto3.setDescripcion("255ml");
        producto3.setVencimiento("27/10/24");
        producto3.setPrecio("Q.5.00");

        Producto producto4 = new Producto();
        producto4.setCodigo("4");
        producto4.setNombre("sprite");
        producto4.setDescripcion("255ml");
        producto4.setVencimiento("27/10/24");
        producto4.setPrecio("Q.4.00");

        Producto producto5 = new Producto();
        producto5.setCodigo("5");
        producto5.setNombre("fanta uva");
        producto5.setDescripcion("255ml");
        producto5.setVencimiento("27/10/24");
        producto5.setPrecio("Q.4.00");

        Producto producto6 = new Producto();
        producto6.setCodigo("6");
        producto6.setNombre("fanta naranja");
        producto6.setDescripcion("255ml");
        producto6.setVencimiento("27/10/24");
        producto6.setPrecio("Q.4.00");

        Producto producto7 = new Producto();
        producto7.setCodigo("7");
        producto7.setNombre("naranjada");
        producto7.setDescripcion("255ml");
        producto7.setVencimiento("27/10/24");
        producto7.setPrecio("Q.3.50");

        Producto producto8 = new Producto();
        producto8.setCodigo("8");
        producto8.setNombre("limonada");
        producto8.setDescripcion("255ml");
        producto8.setVencimiento("27/10/24");
        producto8.setPrecio("Q.3.50");

        Producto producto9 = new Producto();
        producto9.setCodigo("9");
        producto9.setNombre("agua pura");
        producto9.setDescripcion("255ml");
        producto9.setVencimiento("27/10/24");
        producto9.setPrecio("Q.3.00");

        Producto producto10 = new Producto();
        producto10.setCodigo("10");
        producto10.setNombre("doritos");
        producto10.setDescripcion("queso");
        producto10.setVencimiento("27/10/24");
        producto10.setPrecio("Q.4.00");

        Producto producto11 = new Producto();
        producto11.setCodigo("11");
        producto11.setNombre("doritos");
        producto11.setDescripcion("picantes");
        producto11.setVencimiento("27/10/24");
        producto11.setPrecio("Q.4.00");

        Producto producto12 = new Producto();
        producto12.setCodigo("12");
        producto12.setNombre("doritos");
        producto12.setDescripcion("verdes");
        producto12.setVencimiento("27/10/24");
        producto12.setPrecio("Q.4.00");

        Producto producto13 = new Producto();
        producto13.setCodigo("13");
        producto13.setNombre("jalapeños");
        producto13.setDescripcion("100g");
        producto13.setVencimiento("27/10/24");
        producto13.setPrecio("Q.6.00");

        Producto producto14 = new Producto();
        producto14.setCodigo("14");
        producto14.setNombre("nachos");
        producto14.setDescripcion("100g");
        producto14.setVencimiento("27/10/24");
        producto14.setPrecio("Q.6.00");

        Producto producto15 = new Producto();
        producto15.setCodigo("15");
        producto15.setNombre("toztecas");
        producto15.setDescripcion("150g");
        producto15.setVencimiento("27/10/24");
        producto15.setPrecio("Q.12.00");

        Producto producto16 = new Producto();
        producto16.setCodigo("16");
        producto16.setNombre("tortrix");
        producto16.setDescripcion("limon 100g");
        producto16.setVencimiento("27/10/24");
        producto16.setPrecio("Q.3.00");

        Producto producto17 = new Producto();
        producto17.setCodigo("17");
        producto17.setNombre("tortrix");
        producto17.setDescripcion("barbacoa 100g");
        producto17.setVencimiento("27/10/24");
        producto17.setPrecio("Q.3.00");

        Producto producto18 = new Producto();
        producto18.setCodigo("18");
        producto18.setNombre("tortrix");
        producto18.setDescripcion("picante 100g");
        producto18.setVencimiento("27/10/24");
        producto18.setPrecio("Q.3.00");

        Producto producto19 = new Producto();
        producto19.setCodigo("19");
        producto19.setNombre("tortrix");
        producto19.setDescripcion("limon 100g");
        producto19.setVencimiento("27/10/24");
        producto19.setPrecio("Q.3.00");

        Producto producto20 = new Producto();
        producto20.setCodigo("20");
        producto20.setNombre("yuquitas");
        producto20.setDescripcion("200g");
        producto20.setVencimiento("27/10/24");
        producto20.setPrecio("Q.17.00");

        Producto producto21 = new Producto();
        producto21.setCodigo("21");
        producto21.setNombre("taqueritos");
        producto21.setDescripcion("150g");
        producto21.setVencimiento("27/10/24");
        producto21.setPrecio("Q.16.00");

        Producto producto22 = new Producto();
        producto22.setCodigo("22");
        producto22.setNombre("lays");
        producto22.setDescripcion("original 100g");
        producto22.setVencimiento("27/10/24");
        producto22.setPrecio("Q.7.00");

        Producto producto23 = new Producto();
        producto23.setCodigo("23");
        producto23.setNombre("lays");
        producto23.setDescripcion("cebolla 100g");
        producto23.setVencimiento("27/10/24");
        producto23.setPrecio("Q.7.00");

        Producto producto24 = new Producto();
        producto24.setCodigo("24");
        producto24.setNombre("lays");
        producto24.setDescripcion("barbacoa 100g");
        producto24.setVencimiento("27/10/24");
        producto24.setPrecio("Q.7.00");

        Producto producto25 = new Producto();
        producto25.setCodigo("25");
        producto25.setNombre("lays");
        producto25.setDescripcion("picante 100g");
        producto25.setVencimiento("27/10/24");
        producto25.setPrecio("Q.7.00");



        productos.add(producto);
        productos.add(producto2);
        productos.add(producto3);
        productos.add(producto4);
        productos.add(producto5);
        productos.add(producto6);
        productos.add(producto7);
        productos.add(producto8);
        productos.add(producto9);
        productos.add(producto10);
        productos.add(producto11);
        productos.add(producto12);
        productos.add(producto13);
        productos.add(producto14);
        productos.add(producto15);
        productos.add(producto16);
        productos.add(producto17);
        productos.add(producto18);
        productos.add(producto19);
        productos.add(producto20);
        productos.add(producto21);
        productos.add(producto22);
        productos.add(producto23);
        productos.add(producto24);
        productos.add(producto25);

        return productos;
    }


    @RequestMapping(value = "producto3")
    public Producto editar() {
        Producto producto = new Producto();
        producto.setCodigo("1");
        producto.setNombre("manzana");
        producto.setDescripcion("roja");
        producto.setVencimiento("27/10/24");
        producto.setPrecio("Q.3.00");
        return producto;
    }

    @RequestMapping(value = "producto5")
    public Producto eliminar() {
        Producto producto = new Producto();
        producto.setCodigo("1");
        producto.setNombre("manzana");
        producto.setDescripcion("roja");
        producto.setVencimiento("27/10/24");
        producto.setPrecio("Q.3.00");
        return producto;
    }

    @RequestMapping(value = "producto4")
    public Producto buscar() {
        Producto producto = new Producto();
        producto.setCodigo("1");
        producto.setNombre("manzana");
        producto.setDescripcion("roja");
        producto.setVencimiento("27/10/24");
        producto.setPrecio("Q.3.00");
        return producto;
    }

}

