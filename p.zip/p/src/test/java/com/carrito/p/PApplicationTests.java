package com.carrito.p;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PApplicationTests {

	@Test
	void contextLoads() {
	}

}
